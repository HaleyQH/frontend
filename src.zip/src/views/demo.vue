<template>
  <div id="video">
    <video-player
      autoplay
      muted
      class="video-player-box"
      ref="videoPlayer"
      :options="playerOptions"
      :playsinline="true"
    ></video-player>
  </div>
</template>
<script src="https://cdnjs.cloudflare.com/ajax/libs/video.js/7.3.0/video.min.js"></script>
<script>
import axios from 'axios' //axios请求所需引入
import 'video.js/dist/video-js.css'
import 'videojs-flash'
import { videoPlayer } from 'vue-video-player'
export default {
  data: function () {
    return {
      title: '',
      size: '',
      name: [1],
      videoShow: false,
      playerOptions: {
        // videojs options
        autoplay: true,
        // muted: true,
        language: 'en',
        playbackRates: [0.7, 1.0, 1.5, 2.0],
        techOrder: ['flash', 'html5'], //设置顺序，
        sourceOrder: true,
        flash: { hls: { withCredentials: false } },
        html5: { hls: { withCredentials: false } },
        sources: [
          {
            type: 'rtmp/flv',
            src: '',//视频流地址使用axios向后端请求的方式获取
          },
          {
            withCredentials: false,
            type: 'application/x-mpegURL',
          },
        ],

      },
    }
  },
  components: {
    videoPlayer, //注册组件
  },
  mounted() {
    axios.get('/camera/getrtmp?num=1').then((res) => {

      //设置该组件中videoPlayer播放视频的源为从后端请求来的地址
    })
  },
  computed: {
    player() {
      return this.$refs.videoPlayer.player
    },
  },
}
</script>
