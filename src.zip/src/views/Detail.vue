<template>
  <div>
    <el-container>
      <el-header>
        <el-dropdown>
          <div></div>
        </el-dropdown>
      </el-header>
      <el-container>
        <el-aside width="60%">
          <div class="video">
            <video
              ref="videoPlayer"
              width="640" height="480"
              controls autoplay
              :options="playerOptions"
            ></video>
          </div>
          <div class="btn">
            <el-button type="primary" button @click="turn()" icon="el-icon-reading">pdf</el-button>
            <el-button type="primary" button @click="turn" icon="el-icon-s-data">数据集</el-button>
            <el-button type="primary" button @click="turn" icon="el-icon-s-release">代码</el-button>
          </div>
        </el-aside>
        <el-main>

        </el-main>
      </el-container>
    </el-container>
    <div>

    </div>
  </div>
</template>

<script>
import {getVideo} from "@/api/api";
import {videoPlayer} from 'vue-video-player'

export default {
  name: 'Detail',
  data() {
    return {
      playerOptions: {
        autoplay: true,
        // muted: true,
        language: 'en',
        techOrder: ['flash', 'html5'], //设置顺序，
        sourceOrder: true,
        flash: {hls: {withCredentials: false}},
        html5: {hls: {withCredentials: false}},
        sources: [
          {
            type: 'rtmp/flv',
            src: '',//视频流地址使用axios向后端请求的方式获取
          },
          {
            type: 'application/x-mpegURL',
          },
        ],
      },
    }
  }, components: {
    videoPlayer, //注册组件
  }, created() {
    let params = this.$route.params
    if (params.video !== undefined)
      this.Display(params)
  },
  methods: {
    async Display(params) {
      getVideo(params)
        .then(res => {
          console.log("成功执行到这步")
          //  接收视频流数据

          this.playerOptions.sources[0].src = res.data
        });
    },
    turn() {

    }
    // }, beforeRouteEnter(to, from, next) {
    //   from.meta.keepAlive = true;
    //   next();
  }
}
</script>

<style lang="less" scoped>
.video {
  text-align: center;

}

.btn {
  text-align: center;

  button {
    width: 15%;
    margin: 10px 20px;
  }
}
</style>
