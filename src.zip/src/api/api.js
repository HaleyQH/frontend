import requiest from '../utils/requiest'


export const getData = (param) => {
  return requiest(
    {
      url: "/query",
      method: 'get',
      params: param
    }
  )
}

export const getVideo = (params) => {
  return requiest(
    {
      url:"/video",
      method: 'get',
      params: params
    }
  )
}

export const save = (headers, param) => {
  return requiest(
    {
      url: '/',
      method: 'post',
      headers: headers,
      data: param
    }
  )
}
